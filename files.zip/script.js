// ─── Taal Data ───────────────────────────────────────────────────────────────

const TAALS = {
  Dadra: {
    n: 6,
    divs: [3, 3],
    bols: ['Dha', 'Dhin', 'Na', 'Dha', 'Tin', 'Na'],
    vibhagTypes: ['tali', 'khali'],
    fact: "Dadra's 6-beat cycle divides neatly into two equal cosets of ℤ₃ inside ℤ₆, giving it a perfectly mirrored, swaying quality."
  },
  Teentaal: {
    n: 16,
    divs: [4, 4, 4, 4],
    bols: ['Dha','Dhin','Dhin','Dha','Dha','Dhin','Dhin','Dha','Dha','Tin','Tin','Ta','Ta','Dhin','Dhin','Dha'],
    vibhagTypes: ['tali', 'tali', 'khali', 'tali'],
    fact: "Teentaal (ℤ₁₆) is the most complete taal — its 16 matras equal 2⁴, making it rich with nested binary subdivisions."
  },
  Rupak: {
    n: 7,
    divs: [3, 2, 2],
    bols: ['Tin', 'Tin', 'Na', 'Dhin', 'Na', 'Dhin', 'Na'],
    vibhagTypes: ['khali', 'tali', 'tali'],
    fact: "Rupak is the only major taal where Sam itself is Khali — the group ℤ₇ is prime, so it has no proper subgroups."
  },
  Keherwa: {
    n: 8,
    divs: [4, 4],
    bols: ['Dha', 'Ge', 'Na', 'Ti', 'Na', 'Ke', 'Dhin', 'Na'],
    vibhagTypes: ['tali', 'khali'],
    fact: "Keherwa's 8-beat ℤ₈ contains subgroups ℤ₁, ℤ₂, ℤ₄, ℤ₈ — its mathematical richness matches its use across folk and film music."
  },
  Jhaptaal: {
    n: 10,
    divs: [2, 3, 2, 3],
    bols: ['Dhi', 'Na', 'Dhi', 'Dhi', 'Na', 'Ti', 'Na', 'Dhi', 'Dhi', 'Na'],
    vibhagTypes: ['tali', 'tali', 'khali', 'tali'],
    fact: "Jhaptaal's 2+3+2+3 partition is asymmetric — these aren't cosets of a single subgroup, which gives it its characteristic off-balance tension."
  },
  Ektaal: {
    n: 12,
    divs: [2, 2, 2, 2, 2, 2],
    bols: ['Dhin','Dhin','Dhage','Traka','Tu','Na','Ka','Ta','Dhage','Traka','Dhin','Na'],
    vibhagTypes: ['tali', 'tali', 'khali', 'khali', 'tali', 'tali'],
    fact: "Ektaal (ℤ₁₂) shares its cycle length with the Western 12-bar structure — both exploit 12's abundant divisors: 1,2,3,4,6,12."
  },
};

// ─── Color Palette ────────────────────────────────────────────────────────────

const COLORS = {
  sam:     { fill: '#1a4a6b', stroke: '#0d2e45', text: '#ffffff' },
  khali:   { fill: '#8b3a1a', stroke: '#5c2410', text: '#ffffff' },
  tali:    { fill: '#1a6b4a', stroke: '#0d4530', text: '#ffffff' },
  regular: { fill: '#5a4a2a', stroke: '#3a2e18', text: '#ffffff' },
};

const VIBHAG_COLORS = ['#c8760a', '#1a6b4a', '#8b3a1a', '#3a5a8b', '#6b3a8b', '#8b6b1a'];

// ─── State ────────────────────────────────────────────────────────────────────

let currentTaal = 'Teentaal';
let activeBeat  = -1;
let spinAngle   = 0;
let spinRAF     = null;
let isSpinning  = false;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getBeatInfo(taal, beat) {
  const t = TAALS[taal];
  let cursor = 0;
  for (let vi = 0; vi < t.divs.length; vi++) {
    if (beat >= cursor && beat < cursor + t.divs[vi]) {
      const type = beat === 0
        ? 'sam'
        : (t.vibhagTypes[vi] === 'khali' ? 'khali' : 'tali');
      return {
        vibhagIdx:   vi,
        type,
        vibhagLabel: (vi + 1) + 'th',
        vibhagType:  t.vibhagTypes[vi],
      };
    }
    cursor += t.divs[vi];
  }
  return { vibhagIdx: 0, type: 'regular', vibhagLabel: '1st', vibhagType: 'tali' };
}

function buildVibhagOfBeat(taal) {
  const t = TAALS[taal];
  const map = [];
  t.divs.forEach((len, vi) => {
    for (let i = 0; i < len; i++) map.push(vi);
  });
  return map;
}

// ─── Render: Taal Selector ───────────────────────────────────────────────────

function renderTaalSelector() {
  const el = document.getElementById('taal-selector');
  el.innerHTML = Object.entries(TAALS).map(([name, t]) =>
    `<button class="taal-btn${name === currentTaal ? ' active' : ''}" onclick="selectTaal('${name}')">
      ${name}<span class="matras">${t.n}</span>
    </button>`
  ).join('');
}

function selectTaal(name) {
  currentTaal = name;
  activeBeat  = -1;
  stopSpin();
  renderTaalSelector();
  renderAll();
}

// ─── Render: Info Panel ──────────────────────────────────────────────────────

function renderInfo() {
  const t = TAALS[currentTaal];

  // Stats grid
  document.getElementById('info-grid').innerHTML = `
    <div class="info-cell"><div class="lbl">Cyclic Group</div><div class="val">ℤ_${t.n}</div></div>
    <div class="info-cell"><div class="lbl">Total Matras</div><div class="val">${t.n}</div></div>
    <div class="info-cell"><div class="lbl">Vibhags</div><div class="val">${t.divs.length}</div></div>
    <div class="info-cell"><div class="lbl">Division</div><div class="val">${t.divs.join(' + ')}</div></div>
  `;

  // Vibhag row
  let html = '';
  let cursor = 0;
  t.divs.forEach((len, vi) => {
    const typeLabel = t.vibhagTypes[vi] === 'khali' ? 'Khali ×' : 'Tali +';
    html += `<div class="vibhag-group" data-label="${typeLabel}">`;
    for (let i = 0; i < len; i++) {
      const beat = cursor + i;
      const type = beat === 0
        ? 'sam'
        : (t.vibhagTypes[vi] === 'khali' ? 'khali' : 'tali');
      const c = COLORS[type];
      html += `<div class="vibhag-beat" style="background:${c.fill};color:${c.text};border:1.5px solid ${c.stroke}">${beat}</div>`;
    }
    html += '</div>';
    cursor += len;
  });
  document.getElementById('vibhag-row').innerHTML = html;

  // Bol chips
  const vibhagOfBeat = buildVibhagOfBeat(currentTaal);
  document.getElementById('bol-chips').innerHTML = t.bols.map((bol, i) => {
    const col = VIBHAG_COLORS[vibhagOfBeat[i] % VIBHAG_COLORS.length];
    return `<span class="bol-chip" style="border-color:${col};color:${col};background:${col}15">${bol}</span>`;
  }).join('');

  document.getElementById('fun-fact').textContent = t.fact;
}

// ─── Render: Beat Strip ───────────────────────────────────────────────────────

function renderBeatStrip() {
  const t = TAALS[currentTaal];
  const vibhagOfBeat = buildVibhagOfBeat(currentTaal);

  document.getElementById('beat-strip').innerHTML = t.bols.map((bol, i) => {
    const vi   = vibhagOfBeat[i];
    const type = i === 0
      ? 'sam'
      : (t.vibhagTypes[vi] === 'khali' ? 'khali' : 'tali');
    const c        = COLORS[type];
    const isActive = i === activeBeat;
    return `<div class="beat-cell${isActive ? ' active' : ''}"
      style="background:${c.fill}${isActive ? '' : '88'};color:${c.text};border-color:${c.stroke}"
      onclick="selectBeat(${i})" title="${bol}">
      ${i}<span class="bol">${bol}</span>
    </div>`;
  }).join('');
}

function selectBeat(i) {
  activeBeat = i;
  renderBeatStrip();
  renderWheel();
  document.getElementById('beat-input').value = i + 1;
  calcBeat();
}

// ─── Render: Wheel ────────────────────────────────────────────────────────────

function renderWheel() {
  const canvas = document.getElementById('wheel-canvas');
  const ctx    = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const cx = W / 2, cy = H / 2;
  const R      = W * 0.38;
  const innerR = W * 0.12;
  const t = TAALS[currentTaal];
  const n = t.n;

  ctx.clearRect(0, 0, W, H);

  const vibhagOfBeat  = buildVibhagOfBeat(currentTaal);
  const anglePerBeat  = (2 * Math.PI) / n;
  const startOffset   = -Math.PI / 2 + spinAngle;

  for (let i = 0; i < n; i++) {
    const vi   = vibhagOfBeat[i];
    const type = i === 0
      ? 'sam'
      : (t.vibhagTypes[vi] === 'khali' ? 'khali' : 'tali');
    const c        = COLORS[type];
    const start    = startOffset + i * anglePerBeat;
    const end      = start + anglePerBeat;
    const isActive = i === activeBeat;

    // Slice
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, isActive ? R + 10 : R, start, end);
    ctx.closePath();
    ctx.fillStyle   = isActive ? c.fill : c.fill + 'bb';
    ctx.fill();
    ctx.strokeStyle = '#fdf6e8';
    ctx.lineWidth   = 2;
    ctx.stroke();

    // Beat number
    const midAngle = start + anglePerBeat / 2;
    const tx = cx + R * 0.68 * Math.cos(midAngle);
    const ty = cy + R * 0.68 * Math.sin(midAngle);
    ctx.fillStyle    = c.text;
    ctx.font         = `${isActive ? '600' : '400'} ${Math.max(10, W * 0.038)}px 'DM Mono', monospace`;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(i, tx, ty);

    // Bol label outside ring
    const bx = cx + R * 1.13 * Math.cos(midAngle);
    const by = cy + R * 1.13 * Math.sin(midAngle);
    ctx.fillStyle = '#7a6248';
    ctx.font      = `400 ${Math.max(8, W * 0.027)}px 'DM Sans', sans-serif`;
    ctx.fillText(t.bols[i], bx, by);
  }

  // Inner circle
  ctx.beginPath();
  ctx.arc(cx, cy, innerR, 0, 2 * Math.PI);
  ctx.fillStyle   = '#fdf6e8';
  ctx.fill();
  ctx.strokeStyle = '#d4b896';
  ctx.lineWidth   = 1;
  ctx.stroke();

  // Center text
  ctx.fillStyle    = '#1a0f00';
  ctx.font         = `700 ${Math.max(11, W * 0.04)}px 'Playfair Display', serif`;
  ctx.textAlign    = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(currentTaal, cx, cy - 7);

  ctx.font      = `400 ${Math.max(9, W * 0.032)}px 'DM Mono', monospace`;
  ctx.fillStyle = '#c8760a';
  ctx.fillText(`ℤ_${n}`, cx, cy + 10);
}

// ─── Render: All ─────────────────────────────────────────────────────────────

function renderAll() {
  renderWheel();
  renderInfo();
  renderBeatStrip();
}

// ─── Calculators ─────────────────────────────────────────────────────────────

function calcBeat() {
  const t   = TAALS[currentTaal];
  const n   = t.n;
  const raw = parseInt(document.getElementById('beat-input').value);

  if (isNaN(raw) || raw < 1) {
    document.getElementById('beat-result').innerHTML = 'Enter a valid positive integer.';
    return;
  }

  const beat = (raw - 1) % n;
  const { type, vibhagIdx } = getBeatInfo(currentTaal, beat);
  const c         = COLORS[type];
  const typeLabel = type === 'sam'
    ? 'Sam (identity ∅)'
    : type === 'khali'
      ? 'Khali (silent ×)'
      : 'Tali (clap +)';
  const bol = t.bols[beat];

  document.getElementById('beat-result').innerHTML =
    `<div class="eq">Beat ${raw} ≡ ${beat} (mod ${n})</div>` +
    `<div style="margin-top:8px">Matra: <strong>${beat}</strong> &nbsp; Bol: <strong style="color:var(--amber)">${bol}</strong></div>` +
    `<div>Type: <span class="beat-type" style="background:${c.fill};color:${c.text}">${typeLabel}</span></div>` +
    `<div style="margin-top:6px;font-size:11px;color:var(--muted)">Avartana: ${Math.ceil(raw / n)} &nbsp;·&nbsp; Position within vibhag ${vibhagIdx + 1}</div>`;

  activeBeat = beat;
  renderBeatStrip();
  renderWheel();
}

function calcTihai() {
  const t   = TAALS[currentTaal];
  const n   = t.n;
  const len = parseInt(document.getElementById('tihai-len').value);

  if (isNaN(len) || len < 1) {
    document.getElementById('tihai-result').textContent = 'Enter a valid phrase length.';
    return;
  }

  const total = 3 * len;
  const mod   = total % n;
  const start = mod === 0 ? 0 : n - mod;
  const el    = document.getElementById('tihai-result');

  if ((start + total) % n === 0) {
    el.innerHTML = `✓ Start at beat <strong>${start}</strong> · 3×${len} = ${total} · ${total} mod ${n} = ${mod || '0 (fits perfectly)'} · Resolves on Sam ✓`;
  } else {
    el.innerHTML = `Start: ${start} → resolves on beat ${(start + total) % n} (not Sam). Try len = ${Math.ceil(n / 3)} or multiples.`;
  }
}

function calcLay() {
  const t   = TAALS[currentTaal];
  const n   = t.n;
  const lay = parseInt(document.getElementById('lay-input').value);

  if (isNaN(lay) || lay < 1 || lay > 8) {
    document.getElementById('lay-result').textContent = 'Enter lay 1–8.';
    return;
  }

  const effN    = n * lay;
  const mapping = Array.from({ length: n }, (_, k) => `${k}↦${(lay * k) % effN}`)
    .slice(0, 8)
    .join('  ');

  document.getElementById('lay-result').innerHTML =
    `<div class="eq">φ: ℤ_${n} → ℤ_${effN},  k ↦ ${lay}k</div>` +
    `<div style="margin-top:8px;font-size:12px;line-height:2">${mapping}${n > 8 ? '  …' : ''}</div>` +
    `<div style="margin-top:8px;font-size:11px;color:var(--muted)">Effective cycle: ${effN} subdivisions · ${lay} subdivisions per matra</div>`;
}

// ─── Spin Controls ────────────────────────────────────────────────────────────

function toggleSpin() {
  if (isSpinning) stopSpin(); else startSpin();
}

function startSpin() {
  isSpinning = true;
  const btn = document.getElementById('spin-btn');
  btn.textContent = '■ Stop';
  btn.classList.add('spinning');

  const step = () => {
    spinAngle += 0.015;
    renderWheel();
    spinRAF = requestAnimationFrame(step);
  };
  spinRAF = requestAnimationFrame(step);
}

function stopSpin() {
  isSpinning = false;
  if (spinRAF) cancelAnimationFrame(spinRAF);
  const btn = document.getElementById('spin-btn');
  btn.textContent = '▶ Animate Avartana';
  btn.classList.remove('spinning');
}

// ─── Init ─────────────────────────────────────────────────────────────────────

renderTaalSelector();
renderAll();
calcBeat();
calcTihai();
calcLay();
